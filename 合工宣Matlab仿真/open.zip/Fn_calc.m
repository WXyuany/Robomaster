syms ZM_Ddot ZW_Ddot L0(t) theta(t) Tp F P mw g FN

    ZW_Ddot = ZM_Ddot - diff(L0,t,2)*cos(theta) + 2*diff(L0,t)*diff(theta)*sin(theta) + L0*diff(theta,t,2)*sin(theta) + L0*(diff(theta,t)^2)*cos(theta);
    P = F*cos(theta) + (Tp*sin(theta))/L0;
    FN = P + ZW_Ddot + mw*g
